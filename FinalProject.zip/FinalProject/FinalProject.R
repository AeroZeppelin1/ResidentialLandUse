library(ggplot2)
library(dplyr)
library(haven)
library(readxl)
library(car)
library(FSA)
library(plotly)
library(scales)

options(scipen=999) # turns off scientific notation

####file found from https://real-faculty.wharton.upenn.edu/wp-content/uploads/~gyourko/WRLURI/GyourkoHartleyKrimmel_NBERw26573.pdf




#Research Question: Does the Prevalence of residential zoning and land use regulation have a statistically significant effect and a positive relationship on the cost-of-living in a given municipality


setwd("C:/Users/shark/OneDrive/Desktop/RPAD316/FinalProject/StateApproaches")
combined <- read.csv('COMBINED.csv', header=TRUE)
county <- read.csv('County.csv', header=TRUE)

#HYPOTHESIS 1: The propensity of housing regulation in a given state has a statistically significant, positive correlation with the regional price parity of housing in that same state
#Median
  #raw WRLURI value
lm_model_median <- lm(combined$Median.WRLURI18 ~ combined$Housing.RPP, data=combined)
summary(lm_model_median)
  #processed regulation value
combined$median.meaning.numeric <- as.numeric(factor(combined$Median.WRLURI.Meaning, levels = c(
  "Lightly Regulated", "Moderately Regulated", "Highly Regulated")))
lm_model_median2 <- lm(combined$median.meaning.numeric ~ combined$Housing.RPP)
summary(lm_model_median2)
#Not a statistically significant correlation, introducing a control for state income 
lm_model_median3 <- lm(combined$Median.WRLURI18 ~ combined$Housing.RPP + Real.Personal.Income, data=combined)
summary(lm_model_median3)
lm_model_median4 <- lm(combined$median.meaning.numeric ~ combined$Housing.RPP + Real.Personal.Income, data=combined)
summary(lm_model_median4)
#Not a statistically significant correlation. 
#Mean
  #raw WRLURI value
lm_model_mean <- lm(combined$Mean.WRLURI18 ~ combined$Housing.RPP, data=combined)
summary(lm_model_mean)
  #processed regulation value
combined$mean.meaning.numeric <- as.numeric(factor(combined$Mean.WRLURI.Meaning, levels = c(
  "Lightly Regulated", "Moderately Regulated", "Highly Regulated")))
lm_model_mean2 <- lm(combined$mean.meaning.numeric ~ combined$Housing.RPP)
summary(lm_model_mean2)
#Not a statistically significant correlation, including a control for state income for both values
lm_model_mean3 <- lm(combined$Mean.WRLURI18 ~ combined$Housing.RPP + Real.Personal.Income, data=combined)
summary(lm_model_mean3)
lm_model_mean4 <- lm(combined$mean.meaning.numeric ~ combined$Housing.RPP + Real.Personal.Income, data=combined)
summary(lm_model_mean4)
#Not a statistically significant correlation.

#scatterplots

ggplot(data = combined, aes(x = Median.WRLURI18, y = Housing.RPP)) +
  geom_point(color = "blue", size = 2) +  # Scatterplot points
  geom_smooth(method = "lm", color = "red", se = TRUE) +  # Regression line with confidence interval
  labs(title = "Scatterplot of Median Level of Regulation Across States and Housing RPP",
       x = "Level of Regulation", # remember to change the title and the x and y axis to reflect your variables
       y = "Housing RPP") +
  theme_minimal()  # Clean theme

ggplot(data = combined, aes(x = Mean.WRLURI18, y = Housing.RPP)) +
  geom_point(color = "blue", size = 2) +  # Scatterplot points
  geom_smooth(method = "lm", color = "red", se = TRUE) +  # Regression line with confidence interval
  labs(title = "Scatterplot of Mean Level of Regulation Across States and Housing RPP",
       x = "Level of Regulation", # remember to change the title and the x and y axis to reflect your variables
       y = "Housing RPP") +
  theme_minimal()  # Clean theme

ggplot(data = combined, aes(x = median.meaning.numeric, y = Housing.RPP)) +
  geom_point(color = "blue", size = 2) +  # Scatterplot points
  geom_smooth(method = "lm", color = "red", se = TRUE) +  # Regression line with confidence interval
  labs(title = "Scatterplot of Level of Regulation across States and Housing RPP",
       x = "Level of Regulation", # remember to change the title and the x and y axis to reflect your variables
       y = "Housing RPP") +
  theme_minimal()  # Clean theme

ggplot(data = combined, aes(x = mean.meaning.numeric, y = Housing.RPP)) +
  geom_point(color = "blue", size = 2) +  # Scatterplot points
  geom_smooth(method = "lm", color = "red", se = TRUE) +  # Regression line with confidence interval
  labs(title = "Scatterplot of Level of Regulation across States and Housing RPP",
       x = "Level of Regulation", # remember to change the title and the x and y axis to reflect your variables
       y = "Housing RPP") +
  theme_minimal()  # Clean theme

#HYPOTHESIS 2: The propensity of housing regulation in a given county has a statistically significant, positive correlation to the regional price parity of housing in it's state.
#regression analysis
lm_model_county <- lm(county$WRLURI18 ~ county$Housing.RPP, data=county)
summary(lm_model_county)
#Not a statistically significant correlation, introducing a control for state income 
lm_model_county2 <- lm(county$WRLURI18 ~ county$Housing.RPP + Real.Personal.Income, data=county)
summary(lm_model_county2)
#Not a statistically significant correlation.

#Scatterplot
ggplot(data = county, aes(x = WRLURI18, y = Housing.RPP)) +
  geom_point(color = "blue", size = 1, alpha = 0.4) +  # Scatterplot points
  geom_smooth(method = "lm", color = "red", se = TRUE) +  # Regression line with confidence interval
  scale_fill_gradient(low = "lightblue", high = "darkblue") +
  labs(title = "Scatterplot of Level of Regulation across Counties and Housing RPP",
       x = "Level of Regulation", # remember to change the title and the x and y axis to reflect your variables
       y = "Housing RPP") +
  theme_minimal()  # Clean theme

####third approach, taking counties by metropolitan areas' housing RPP instead of State, filtering out non-metropolitan areas and only including those which match
setwd("C:/Users/shark/OneDrive/Desktop/RPAD316/FinalProject/CBSAApproaches")
CBSA <- read.csv('CBSA.csv', header=TRUE)

#HYPOTHESIS 3: The propensity of housing regulation in a given county has a statistically significant, positive correlation to the regional price parity of housing of that county's metropolitan area.
lm_model_CBSA <- lm(CBSA$WRLURI18 ~ CBSA$Housing.RPP)
summary(lm_model_CBSA)
#statistically significant 

#scatterplot
ggplot(data = CBSA, aes(x = WRLURI18, y = Housing.RPP)) +
  geom_point(color = "blue", size = 1, alpha = 0.4) +  # Scatterplot points
  geom_smooth(method = "lm", color = "red", se = TRUE) +  # Regression line with confidence interval
  scale_fill_gradient(low = "lightblue", high = "darkblue") +
  labs(title = "Scatterplot of Level of Regulation across Counties and Housing RPP",
       x = "Level of Regulation", # remember to change the title and the x and y axis to reflect your variables
       y = "Housing RPP") +
  theme_minimal()  # Clean theme


#instead of regression analysis, ANOVA analysis using categorical light, medium, and highly regulated categories?
#Additional testing of Hypothesis 3
fr_table_regulations <- CBSA %>% #save new data object as fr for "frequency" and name of variable
  group_by(Regulations) %>% 
  summarise(count = n())
print(fr_table_regulations)

correlation_result <- cor(CBSA$Housing.RPP, CBSA$WRLURI18, use = "complete.obs")
print(correlation_result)
#moderate positive correlation between the regional price partities of housing across metropolitan areas and WRLURI18 values across counties
#levene test
leveneTest1 <- leveneTest(Housing.RPP ~ Regulations, data=CBSA)
print(leveneTest1)
#Variances NOT equal
welch_anova_result1 <- oneway.test(Housing.RPP ~ Regulations, data = CBSA, var.equal = FALSE)
print(welch_anova_result1)
dunn_test_result1 <- dunnTest(Housing.RPP ~ Regulations, data = CBSA, method = "bonferroni")
print(dunn_test_result1)




#introducing real personal income as a control variable 
lm_model_control1 <- lm(CBSA$WRLURI18 ~ CBSA$Housing.RPP + CBSA$RealPersonalIncome)
summary(lm_model_control1)
#this type of control did not work; using scale instead
CBSA$RPI.Standardized <- scale(CBSA$RealPersonalIncome)
lm_model_control2 <- lm(WRLURI18 ~ Housing.RPP + RPI.Standardized, data = CBSA)
summary(lm_model_control2)
#trying interaction terms
lm_model_interaction <- lm(WRLURI18 ~ Housing.RPP * RealPersonalIncome, data = CBSA)
summary(lm_model_interaction)
#If real personal income increases, the positive effect of WRLURI values on regional price parities of housing becomes stronger as suggested by the positive interaction coefficient 
#plot 
ggplot(CBSA, aes(x = Housing.RPP, y = WRLURI18, color = RealPersonalIncome)) +
  geom_point() +
  geom_smooth(method = "lm", formula = y ~ x * z) +
  labs(title = "Interaction Effect of Housing.RPP and RealPersonalIncome",
       x = "Housing.RPP",
       y = "WRLURI18")

